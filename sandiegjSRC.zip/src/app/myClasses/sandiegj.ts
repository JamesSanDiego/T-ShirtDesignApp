export class Sandiegj{
  fname: string;
  lname: string;
  studentnum: number;
  username: string;
  homecountry: string;
  currentcity: string;
  pic: string;
}